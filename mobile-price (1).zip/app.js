var phones = [];


function addPhone() {

var name =
document.getElementById("phoneName").value;

var price =
document.getElementById("phonePrice").value;

var brand =
document.getElementById("phoneBrand").value;


if (name == "") {

alert("نام گوشی را وارد کن");

return;

}


if (price == "") {

alert("قیمت را وارد کن");

return;

}


phones.push({

name: name,

price: price,

brand: brand

});


document.getElementById("phoneName").value = "";

document.getElementById("phonePrice").value = "";


showPhones();

}


function showPhones() {

var list =
document.getElementById("phoneList");

var search =
document.getElementById("search").value.toLowerCase();


list.innerHTML = "";


for (var i = 0; i < phones.length; i++) {

var phone = phones[i];


if (
phone.name.toLowerCase().indexOf(search) == -1
) {

continue;

}


list.innerHTML +=

"<div class='phone'>" +

"<h2>" +
phone.name +
"</h2>" +

"<p>" +
phone.brand +
"</p>" +

"<p class='price'>" +
phone.price +
" تومان</p>" +

"<button class='edit' onclick='editPhone(" +
i +
")'>✏️ ویرایش</button> " +

"<button class='delete' onclick='deletePhone(" +
i +
")'>🗑️ حذف</button>" +

"</div>";

}

}


function editPhone(index) {

var name =
prompt(
"نام گوشی:",
phones[index].name
);

if (name == null) return;


var price =
prompt(
"قیمت:",
phones[index].price
);

if (price == null) return;


phones[index].name = name;

phones[index].price = price;


showPhones();

}


function deletePhone(index) {

if (
confirm("این گوشی حذف شود؟")
) {

phones.splice(index, 1);

showPhones();

}

}


showPhones();